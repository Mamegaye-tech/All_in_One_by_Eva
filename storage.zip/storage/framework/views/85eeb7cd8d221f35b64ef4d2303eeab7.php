<?php $__env->startSection('title', 'Modifier le client'); ?>

<?php $__env->startSection('content'); ?>
<div class="mx-auto max-w-3xl">
    <h1 class="mb-6 text-2xl font-semibold text-[#780D25]">Modifier <?php echo e($client->nom_complet); ?></h1>
    <form method="POST" action="<?php echo e(route('clients.update', $client)); ?>" class="rounded-xl bg-white p-6 shadow-sm">
        <?php echo method_field('PUT'); ?>
        <?php echo $__env->make('clients._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\All_ine_One_by_Eva\resources\views/clients/edit.blade.php ENDPATH**/ ?>