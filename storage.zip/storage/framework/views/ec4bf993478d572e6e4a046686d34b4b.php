<?php $__env->startSection('title', 'Clients'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $teintes = ['bg-[#e8b5c6]', 'bg-[#f3d3df]', 'bg-[#dfb3d7]', 'bg-[#f5bfd0]'];
?>

<div class="space-y-6 text-[#321b25]">

    
    <div class="flex flex-wrap items-center justify-between gap-4">
        <div class="flex items-center gap-4">
            <span class="flex h-12 w-12 items-center justify-center rounded-xl bg-[#f8d5e2] text-xl text-[#a51c50]">
                <i class="fa-solid fa-users"></i>
            </span>
            <div>
                <h1 class="text-2xl font-bold">Gestion des clients</h1>
                <p class="text-sm text-[#806d76]">Consultez et gérez tous vos clients.</p>
            </div>
        </div>

        <a href="<?php echo e(route('clients.create')); ?>"
           class="rounded-xl bg-[#a51c50] px-6 py-3 font-semibold text-white shadow-md transition hover:bg-[#8e1646]">
            <i class="fa-solid fa-plus mr-2"></i>Ajouter un client
        </a>
    </div>

    <?php if(session('success')): ?>
        <p class="rounded-lg bg-emerald-50 px-4 py-2 text-sm text-emerald-700"><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    
    <div class="overflow-hidden rounded-2xl bg-white shadow-[0_3px_10px_#e8d7df]">
        <div class="overflow-x-auto">
            <table class="w-full min-w-[640px] text-left">
                <thead class="bg-[#fbeef3] text-sm font-semibold">
                    <tr>
                        <th class="px-6 py-4">Client</th>
                        <th class="px-6 py-4">Téléphone</th>
                        <th class="px-6 py-4">Date d'inscription</th>
                        <th class="w-32 px-6 py-4 text-right">Actions</th>
                    </tr>
                </thead>

                <tbody class="divide-y divide-[#f0dfe7] text-sm">
                    <?php $__empty_1 = true; $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="transition hover:bg-[#fffafc]">
                            <td class="px-6 py-4">
                                <div class="flex items-center  gap-4">
                                    <span class="flex h-11 w-11 shrink-0 items-center justify-center rounded-full font-bold text-[#780d25] <?php echo e($teintes[$client->id % count($teintes)]); ?>">
                                        <?php echo e(strtoupper(mb_substr($client->prenom, 0, 1) . mb_substr($client->nom, 0, 1))); ?>

                                    </span>
                                    <div>
                                        <a href="<?php echo e(route('clients.show', $client)); ?>" class="text-base font-semibold hover:text-[#a51c50]">
                                            <?php echo e($client->nom_complet); ?>

                                        </a>
                                        <?php if($client->statut): ?>
                                            <p class="text-xs text-[#806d76]"><?php echo e(ucfirst(str_replace('_', ' ', $client->statut->value))); ?></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>

                            <td class="px-6 py-4 text-base"><?php echo e($client->telephone); ?></td>

                            <td class="px-6 py-4 text-base"><?php echo e($client->date_inscription?->format('d/m/Y')); ?></td>

                            <td class="px-6 py-4">
                                <div class="flex items-center justify-end gap-6 text-lg">
                                    <a href="<?php echo e(route('clients.edit', $client)); ?>" aria-label="Modifier" title="Modifier"
                                       class="text-[#e8923a] transition hover:scale-110">
                                        <i class="fa-solid fa-pen"></i>
                                    </a>

                                    <form method="POST" action="<?php echo e(route('clients.destroy', $client)); ?>"
                                          onsubmit="return confirm('Archiver ce client ?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" aria-label="Archiver" title="Archiver"
                                                class="text-[#d9304f] transition hover:scale-110">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="px-6 py-10 text-center text-[#806d76]">Aucun client trouvé.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <?php if($clients instanceof \Illuminate\Pagination\LengthAwarePaginator && $clients->hasPages()): ?>
        <nav class="flex items-center justify-center gap-2" aria-label="Pagination">
            <?php if($clients->onFirstPage()): ?>
                <span class="flex h-9 w-9 items-center justify-center text-gray-300"><i class="fa-solid fa-chevron-left text-xs"></i></span>
            <?php else: ?>
                <a href="<?php echo e($clients->previousPageUrl()); ?>" class="flex h-9 w-9 items-center justify-center text-[#806d76] hover:text-[#a51c50]">
                    <i class="fa-solid fa-chevron-left text-xs"></i>
                </a>
            <?php endif; ?>

            <?php $__currentLoopData = $clients->getUrlRange(1, $clients->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e($url); ?>"
                   class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                       'flex h-9 w-9 items-center justify-center rounded-lg text-sm font-medium transition',
                       'bg-[#a51c50] text-white shadow' => $page === $clients->currentPage(),
                       'hover:bg-[#f5edf1]' => $page !== $clients->currentPage(),
                   ]); ?>"><?php echo e($page); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if($clients->hasMorePages()): ?>
                <a href="<?php echo e($clients->nextPageUrl()); ?>" class="flex h-9 w-9 items-center justify-center text-[#806d76] hover:text-[#a51c50]">
                    <i class="fa-solid fa-chevron-right text-xs"></i>
                </a>
            <?php else: ?>
                <span class="flex h-9 w-9 items-center justify-center text-gray-300"><i class="fa-solid fa-chevron-right text-xs"></i></span>
            <?php endif; ?>
        </nav>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\All_ine_One_by_Eva\resources\views/clients/index.blade.php ENDPATH**/ ?>