<?php $__env->startSection('title', $client->nom_complet); ?>

<?php $__env->startSection('content'); ?>
<div class="mx-auto max-w-4xl space-y-6">
    <?php if(session('success')): ?>
        <div class="rounded-lg bg-green-50 px-4 py-3 text-sm text-green-800"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="flex flex-wrap items-center justify-between gap-3">
        <div>
            <h1 class="text-2xl font-semibold text-[#780D25]"><?php echo e($client->nom_complet); ?></h1>
            <span class="mt-1 inline-block rounded-full px-2 py-1 text-xs <?php echo e($client->statut === App\Enums\StatutClient::Actif ? 'bg-green-100 text-green-800' : 'bg-gray-200 text-gray-600'); ?>">
                <?php echo e($client->statut->label()); ?>

            </span>
        </div>
        <div class="flex flex-wrap gap-2">
            <?php if($lien = $client->lienWhatsApp('Bonjour '.$client->prenom.' !')): ?>
                <a href="<?php echo e($lien); ?>" target="_blank" rel="noopener"
                   class="rounded-lg bg-green-600 px-4 py-2 text-sm text-white hover:bg-green-700">Envoyer un message WhatsApp</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $client)): ?>
                <a href="<?php echo e(route('clients.edit', $client)); ?>" class="rounded-lg border border-[#780D25] px-4 py-2 text-sm text-[#780D25]">Modifier</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('toggleStatus', $client)): ?>
                <?php $actif = $client->statut === App\Enums\StatutClient::Actif; ?>
                <form method="POST" action="<?php echo e(route('clients.toggle-status', $client)); ?>"
                      onsubmit="return confirm('<?php echo e($actif ? 'Désactiver' : 'Réactiver'); ?> ce client ?')">
                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                    <button class="rounded-lg border border-gray-300 px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
                        <?php echo e($actif ? 'Désactiver' : 'Réactiver'); ?>

                    </button>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <div class="grid gap-4 rounded-xl bg-white p-6 shadow-sm sm:grid-cols-2">
        <div><p class="text-xs text-gray-500">Téléphone</p><p><?php echo e($client->telephone_affiche); ?></p></div>
        <div><p class="text-xs text-gray-500">WhatsApp</p><p><?php echo e($client->whatsapp_affiche); ?></p></div>
        <div><p class="text-xs text-gray-500">E-mail</p><p><?php echo e($client->email ?? '—'); ?></p></div>
        <div><p class="text-xs text-gray-500">Date de naissance</p><p><?php echo e($client->date_naissance?->translatedFormat('d F Y') ?? 'Non renseignée'); ?></p></div>
        <div><p class="text-xs text-gray-500">Préférence de communication</p><p><?php echo e(App\Http\Requests\ClientRequest::PREFERENCES[$client->preference_communication] ?? '—'); ?></p></div>
        <div><p class="text-xs text-gray-500">Inscrit le</p><p><?php echo e($client->date_inscription?->format('d/m/Y') ?? '—'); ?></p></div>
        <div>
            <p class="text-xs text-gray-500">Messages promotionnels</p>
            <p>
                <?php echo e($client->consentement_promo ? 'Accepté' : 'Non accepté'); ?>

                <?php if($client->consentement_modifie_le): ?>
                    <span class="text-xs text-gray-500">(modifié le <?php echo e($client->consentement_modifie_le->format('d/m/Y')); ?>)</span>
                <?php endif; ?>
            </p>
        </div>
        <div><p class="text-xs text-gray-500">Préférences de prestations</p><p><?php echo e($client->preferences_prestations ?? '—'); ?></p></div>
        <div class="sm:col-span-2"><p class="text-xs text-gray-500">Notes</p><p class="whitespace-pre-line"><?php echo e($client->notes ?? '—'); ?></p></div>
    </div>

    <p class="text-xs text-gray-500">L'historique des rendez-vous, des paiements et de la fidélité sera ajouté à cette fiche dans l'étape suivante.</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\All_ine_One_by_Eva\resources\views/clients/show.blade.php ENDPATH**/ ?>