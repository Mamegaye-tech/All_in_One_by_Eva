<?php
    $field = 'mt-1 block w-full rounded-lg border-gray-300 text-sm focus:border-[#780D25] focus:ring-[#780D25]';
?>

<?php echo csrf_field(); ?>
<div class="grid gap-5 sm:grid-cols-2">
    <div>
        <label class="text-sm font-medium">Prénom *</label>
        <input type="text" name="prenom" value="<?php echo e(old('prenom', $client->prenom)); ?>" required class="<?php echo e($field); ?>">
        <?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div>
        <label class="text-sm font-medium">Nom *</label>
        <input type="text" name="nom" value="<?php echo e(old('nom', $client->nom)); ?>" required class="<?php echo e($field); ?>">
        <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div>
        <label class="text-sm font-medium">Téléphone *</label>
        <input type="tel" name="telephone" value="<?php echo e(old('telephone', $client->telephone ? '+'.$client->telephone : '')); ?>"
               placeholder="77 123 45 67" required class="<?php echo e($field); ?>">
        <?php $__errorArgs = ['telephone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div>
        <label class="text-sm font-medium">WhatsApp (si différent)</label>
        <input type="tel" name="whatsapp" value="<?php echo e(old('whatsapp', $client->whatsapp ? '+'.$client->whatsapp : '')); ?>" class="<?php echo e($field); ?>">
        <?php $__errorArgs = ['whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div>
        <label class="text-sm font-medium">E-mail</label>
        <input type="email" name="email" value="<?php echo e(old('email', $client->email)); ?>" class="<?php echo e($field); ?>">
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div>
        <label class="text-sm font-medium">Date de naissance</label>
        <input type="date" name="date_naissance" max="<?php echo e(now()->toDateString()); ?>"
               value="<?php echo e(old('date_naissance', $client->date_naissance?->format('Y-m-d'))); ?>" class="<?php echo e($field); ?>">
        <?php $__errorArgs = ['date_naissance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div>
        <label class="text-sm font-medium">Préférence de communication *</label>
        <select name="preference_communication" class="<?php echo e($field); ?>">
            <?php $__currentLoopData = App\Http\Requests\ClientRequest::PREFERENCES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($value); ?>" <?php if(old('preference_communication', $client->preference_communication) === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['preference_communication'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div>
        <label class="text-sm font-medium">Préférences de prestations</label>
        <input type="text" name="preferences_prestations" value="<?php echo e(old('preferences_prestations', $client->preferences_prestations)); ?>"
               placeholder="Ex. tresses, manucure" class="<?php echo e($field); ?>">
        <?php $__errorArgs = ['preferences_prestations'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="sm:col-span-2">
        <label class="flex items-center gap-2 text-sm">
            <input type="checkbox" name="consentement_promo" value="1" <?php if(old('consentement_promo', $client->consentement_promo)): echo 'checked'; endif; ?>
                   class="rounded border-gray-300 text-[#780D25] focus:ring-[#780D25]">
            Le client accepte de recevoir des messages promotionnels
        </label>
    </div>
    <div class="sm:col-span-2">
        <label class="text-sm font-medium">Notes utiles</label>
        <textarea name="notes" rows="3" class="<?php echo e($field); ?>"><?php echo e(old('notes', $client->notes)); ?></textarea>
        <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="mt-6 flex gap-3">
    <button type="submit" class="rounded-lg bg-[#780D25] px-5 py-2 text-sm text-white hover:opacity-90">Enregistrer</button>
    <a href="<?php echo e(route('clients.index')); ?>" class="rounded-lg px-5 py-2 text-sm text-gray-600 hover:bg-white">Annuler</a>
</div><?php /**PATH C:\xampp\htdocs\All_ine_One_by_Eva\resources\views/clients/_form.blade.php ENDPATH**/ ?>