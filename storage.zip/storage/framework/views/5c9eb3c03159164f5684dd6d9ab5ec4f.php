<?php $__env->startSection('content'); ?>
<?php
    $couleurs = [
        'amber' => 'bg-[#e8923a]',
        'sky' => 'bg-[#3a9ad9]',
        'violet' => 'bg-[#7b3fa0]',
        'emerald' => 'bg-[#2e9e6b]',
        'stone' => 'bg-[#9a8f94]',
    ];
    $champ = 'mt-1 w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:border-[#a51c50] focus:outline-none focus:ring-1 focus:ring-[#a51c50]';
    $label = 'mt-3 block text-sm font-medium text-[#321b25]';
    $erreur = 'mt-1 text-sm text-red-600';
?>

<div class="grid grid-cols-1 gap-6 text-[#321b25] xl:grid-cols-[1fr_320px]">

    
    <div class="flex flex-wrap items-center justify-between gap-4 xl:col-span-2">
        <div class="flex items-center gap-4">
            <span class="flex h-12 w-12 items-center justify-center rounded-xl bg-[#f8d5e2] text-xl text-[#a51c50]">
                <i class="fa-solid fa-gift"></i>
            </span>
            <div>
                <h1 class="text-2xl font-bold">Gestion des rendez-vous</h1>
                <p class="text-sm text-[#806d76]">Planifiez et suivez vos rendez-vous.</p>
            </div>
        </div>

        <button type="button"
                onclick="document.getElementById('modal-rdv').showModal()"
                class="rounded-xl bg-[#a51c50] px-6 py-3 font-semibold text-white shadow-md transition hover:bg-[#8e1646]">
            <i class="fa-solid fa-plus mr-2"></i>Nouveau rendez-vous
        </button>
    </div>

    <?php if(session('success')): ?>
        <p class="rounded-lg bg-emerald-50 px-4 py-2 text-sm text-emerald-700 xl:col-span-2"><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    
    <section class="rounded-2xl bg-white p-6 shadow-[0_3px_10px_#e8d7df]">
        <div class="flex flex-wrap items-center justify-between gap-3">
            <div class="flex items-center gap-4">
                <a href="<?php echo e(route('rendez-vous.index', ['mois' => $mois->copy()->subMonth()->format('Y-m')])); ?>"
                   class="flex h-9 w-9 items-center justify-center rounded-lg bg-[#f5edf1] transition hover:bg-[#f0dfe7]">
                    <i class="fa-solid fa-chevron-left text-xs"></i>
                </a>
                <span class="text-lg font-bold"><?php echo e(ucfirst($mois->copy()->locale('fr')->translatedFormat('F Y'))); ?></span>
                <a href="<?php echo e(route('rendez-vous.index', ['mois' => $mois->copy()->addMonth()->format('Y-m')])); ?>"
                   class="flex h-9 w-9 items-center justify-center rounded-lg bg-[#f5edf1] transition hover:bg-[#f0dfe7]">
                    <i class="fa-solid fa-chevron-right text-xs"></i>
                </a>
            </div>

            <div class="flex gap-2">
                <a href="#" class="rounded-lg bg-[#f5edf1] px-5 py-2 text-sm font-medium transition hover:bg-[#f0dfe7]">Jour</a>
                <a href="#" class="rounded-lg bg-[#f5edf1] px-5 py-2 text-sm font-medium transition hover:bg-[#f0dfe7]">Semaine</a>
                <a href="#" class="rounded-lg bg-[#780d25] px-5 py-2 text-sm font-medium text-white">Mois</a>
            </div>
        </div>

        <div class="mt-6 grid grid-cols-7 gap-y-3 text-center">
            <?php $__currentLoopData = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="pb-2 text-sm font-semibold text-[#806d76]"><?php echo e($n); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php for($d = $debutGrille->copy(); $d <= $finGrille; $d->addDay()): ?>
                <?php
                    $estAujourdhui = $d->isToday();
                    $estChoisi = $d->isSameDay($jour);
                    $autreMois = $d->month != $mois->month;
                ?>
                <a href="<?php echo e(route('rendez-vous.index', ['mois' => $mois->format('Y-m'), 'jour' => $d->toDateString()])); ?>"
                   class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                       'relative mx-auto flex h-11 w-11 items-center justify-center rounded-full text-base transition',
                       'bg-[#780d25] font-bold text-white' => $estAujourdhui,
                       'hover:bg-[#f5edf1]' => ! $estAujourdhui,
                       'text-gray-300' => $autreMois && ! $estAujourdhui,
                       'ring-2 ring-[#a51c50] ring-offset-2' => $estChoisi && ! $estAujourdhui,
                   ]); ?>">
                    <?php echo e($d->day); ?>

                    <?php if($joursAvecRdv->has($d->toDateString())): ?>
                        <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                            'absolute bottom-1 h-1.5 w-1.5 rounded-full',
                            'bg-white' => $estAujourdhui,
                            'bg-[#a51c50]' => ! $estAujourdhui,
                        ]); ?>"></span>
                    <?php endif; ?>
                </a>
            <?php endfor; ?>
        </div>
    </section>

    
    <aside class="rounded-2xl bg-white p-6 shadow-[0_3px_10px_#e8d7df]">
        <h3 class="text-lg font-bold">Rendez-vous du jour</h3>
        <p class="text-sm text-[#806d76]"><?php echo e($jour->copy()->locale('fr')->translatedFormat('l j F Y')); ?></p>

        <div class="mt-5 space-y-5">
            <?php $__empty_1 = true; $__currentLoopData = $rdvDuJour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rdv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex gap-3">
                    <span class="mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full <?php echo e($couleurs[$rdv->statut->tone()]); ?>"></span>
                    <div class="min-w-0">
                        <p class="text-sm font-semibold">
                            <?php echo e($rdv->debut->format('H:i')); ?> – <?php echo e($rdv->libellePrestations() ?: 'Sans prestation'); ?>

                        </p>
                        <p class="text-xs text-[#806d76]">Avec <?php echo e($rdv->client?->nom_complet ?: 'Client'); ?></p>

                        <form method="POST" action="<?php echo e(route('rendez-vous.statut', $rdv)); ?>" class="mt-1">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <select name="statut" onchange="this.form.submit()"
                                    class="rounded-md border border-gray-200 bg-white px-2 py-1 text-xs focus:border-[#a51c50] focus:outline-none">
                                <?php $__currentLoopData = \App\Enums\StatutRendezVous::cases(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($st->value); ?>" <?php if($rdv->statut === $st): echo 'selected'; endif; ?>><?php echo e($st->label()); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-sm text-[#806d76]">Aucun rendez-vous ce jour.</p>
            <?php endif; ?>
        </div>
    </aside>
</div>


<dialog id="modal-rdv" class="m-auto w-[min(92vw,460px)] rounded-2xl p-0 shadow-xl backdrop:bg-black/40">
    <form method="POST" action="<?php echo e(route('rendez-vous.store')); ?>" class="max-h-[90vh] overflow-y-auto p-6">
        <?php echo csrf_field(); ?>
        <h3 class="text-xl font-bold">Nouveau rendez-vous</h3>

        <?php $__errorArgs = ['regle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="<?php echo e($erreur); ?>"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label class="<?php echo e($label); ?>">Client</label>
        <select name="client_id" required class="<?php echo e($champ); ?>">
            <?php $__currentLoopData = \App\Models\Client::orderBy('nom')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($c->id); ?>" <?php if(old('client_id') == $c->id): echo 'selected'; endif; ?>><?php echo e($c->nom_complet); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['client_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="<?php echo e($erreur); ?>"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label class="<?php echo e($label); ?>">Employé</label>
        <select name="employe_id" required class="<?php echo e($champ); ?>">
            <?php $__currentLoopData = \App\Models\Employe::orderBy('nom')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($e->id); ?>" <?php if(old('employe_id') == $e->id): echo 'selected'; endif; ?>><?php echo e($e->nom_complet); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['employe_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="<?php echo e($erreur); ?>"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="grid grid-cols-2 gap-3">
            <div>
                <label class="<?php echo e($label); ?>">Date</label>
                <input type="date" name="date" value="<?php echo e(old('date', $jour->toDateString())); ?>" required class="<?php echo e($champ); ?>">
                <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="<?php echo e($erreur); ?>"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label class="<?php echo e($label); ?>">Heure de début</label>
                <input type="time" name="heure_debut" value="<?php echo e(old('heure_debut')); ?>" required class="<?php echo e($champ); ?>">
                <?php $__errorArgs = ['heure_debut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="<?php echo e($erreur); ?>"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <label class="<?php echo e($label); ?>">Zone</label>
        <select name="zone" id="zone" required class="<?php echo e($champ); ?>">
            <?php $__currentLoopData = \App\Enums\ZoneSalon::cases(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $z): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($z->value); ?>" <?php if(old('zone') == $z->value): echo 'selected'; endif; ?>><?php echo e($z->label()); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['zone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="<?php echo e($erreur); ?>"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label class="<?php echo e($label); ?>">Prestations</label>
        <select name="services[]" id="services" multiple class="<?php echo e($champ); ?> h-28">
            <?php $__currentLoopData = \App\Models\Service::actifs()->orderBy('nom')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($s->id); ?>" data-zone="<?php echo e($s->zone->value); ?>"
                        <?php if(in_array($s->id, old('services', []))): echo 'selected'; endif; ?>>
                    <?php echo e($s->nom); ?> – <?php echo e(number_format($s->prix, 0, ',', ' ')); ?> FCFA
                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['services'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="<?php echo e($erreur); ?>"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label class="<?php echo e($label); ?>">Forfaits</label>
        <select name="forfaits[]" multiple class="<?php echo e($champ); ?> h-20">
            <?php $__currentLoopData = \App\Models\Forfait::actifs()->orderBy('nom')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($f->id); ?>" <?php if(in_array($f->id, old('forfaits', []))): echo 'selected'; endif; ?>>
                    <?php echo e($f->nom); ?> – <?php echo e(number_format($f->prix, 0, ',', ' ')); ?> FCFA
                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <p class="mt-1 text-xs text-[#806d76]">
            Ctrl + clic pour en choisir plusieurs. Choisissez au moins une prestation ou un forfait. La fin et le prix sont calculés automatiquement.
        </p>

        <label class="<?php echo e($label); ?>">Commentaire</label>
        <textarea name="commentaire" rows="2" class="<?php echo e($champ); ?>"><?php echo e(old('commentaire')); ?></textarea>

        <div class="mt-6 flex justify-end gap-3">
            <button type="button" onclick="this.closest('dialog').close()"
                    class="rounded-lg bg-[#f5edf1] px-5 py-2 text-sm font-medium transition hover:bg-[#f0dfe7]">
                Annuler
            </button>
            <button type="submit"
                    class="rounded-lg bg-[#a51c50] px-5 py-2 text-sm font-semibold text-white transition hover:bg-[#8e1646]">
                Enregistrer
            </button>
        </div>
    </form>
</dialog>

<?php if($errors->any()): ?>
<script>document.getElementById('modal-rdv').showModal();</script>
<?php endif; ?>

<script>
    // N'affiche que les prestations de la zone choisie
    const zone = document.getElementById('zone');
    const services = document.getElementById('services');
    function filtrerServices() {
        [...services.options].forEach(o => {
            o.hidden = o.dataset.zone !== zone.value;
            if (o.hidden) o.selected = false;
        });
    }
    zone.addEventListener('change', filtrerServices);
    filtrerServices();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\All_ine_One_by_Eva\resources\views/rendez-vous/index.blade.php ENDPATH**/ ?>