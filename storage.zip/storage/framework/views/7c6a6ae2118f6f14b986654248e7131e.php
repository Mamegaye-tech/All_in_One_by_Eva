<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['route', 'icon', 'pattern' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['route', 'icon', 'pattern' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $actif = request()->routeIs($pattern ?? $route);
?>

<a href="<?php echo e($route === '#' ? '#' : route($route)); ?>"
    class="flex items-center gap-3 px-3 py-2 rounded-xl <?php echo e($actif ? 'bg-[#C52F6C]' : 'hover:bg-white/10'); ?>">
    <i class="fas <?php echo e($icon); ?> w-6 text-lg"></i>
    <span><?php echo e($slot); ?></span>
</a><?php /**PATH C:\xampp\htdocs\All_ine_One_by_Eva\resources\views/components/nav-link.blade.php ENDPATH**/ ?>