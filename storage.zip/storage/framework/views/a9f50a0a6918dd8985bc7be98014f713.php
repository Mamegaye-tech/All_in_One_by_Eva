<?php $__env->startSection('contenu'); ?>

<style>
    .form-page {
        background: #fff7fa;
        min-height: 100vh;
        padding: 25px 28px;
        color: #390c29;
    }

    .form-page h1 {
        font-size: 32px;
        font-weight: bold;
        color: #780d35;
        margin-bottom: 5px;
    }

    .form-page .sous-titre {
        color: #563b4c;
        margin-bottom: 30px;
    }

    .form-card {
        background: white;
        border: 1px solid #f0dce6;
        border-radius: 18px;
        padding: 30px;
        max-width: 800px;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        font-weight: 600;
        margin-bottom: 8px;
    }

    .form-group input[type="text"],
    .form-group input[type="number"],
    .form-group input[type="file"],
    .form-group textarea {
        width: 100%;
        padding: 12px 16px;
        border: 1px solid #f0dce6;
        border-radius: 12px;
        background: #fff7fa;
        outline: none;
        font-size: 15px;
    }

    .form-group input:focus,
    .form-group textarea:focus {
        border-color: #780d35;
    }

    .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }

    .erreur {
        color: #bd1a1a;
        font-size: 14px;
        margin-top: 5px;
    }

    .image-actuelle {
        width: 160px;
        height: 90px;
        object-fit: cover;
        border-radius: 12px;
        margin-bottom: 10px;
    }

    .btn-enregistrer {
        background: #780d35;
        color: white;
        padding: 14px 26px;
        border-radius: 13px;
        border: none;
        font-weight: 600;
        cursor: pointer;
    }

    .btn-enregistrer:hover {
        background: #a51b56;
    }

    .btn-annuler {
        display: inline-block;
        padding: 14px 26px;
        border-radius: 13px;
        background: #f9eaf1;
        color: #780d35;
        font-weight: 600;
        text-decoration: none;
        margin-left: 10px;
    }

    @media(max-width: 600px) {
        .form-row {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="form-page">

    <h1><i class="fas fa-pen"></i> Modifier la prestation</h1>
    <p class="sous-titre">Modifiez les informations de « <?php echo e($prestation->nom); ?> ».</p>

    <div class="form-card">

        <form action="<?php echo e(route('prestations.update', $prestation->id)); ?>"
              method="POST"
              enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label for="nom">Nom de la prestation</label>
                <input type="text" id="nom" name="nom"
                       value="<?php echo e(old('nom', $prestation->nom)); ?>">
                <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="erreur"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="description">Description</label>
                <textarea id="description" name="description" rows="4"><?php echo e(old('description', $prestation->description)); ?></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="erreur"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="categorie">Catégorie</label>
                <input type="text" id="categorie" name="categorie"
                       value="<?php echo e(old('categorie', $prestation->categorie)); ?>">
                <?php $__errorArgs = ['categorie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="erreur"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="prix">Prix (FCFA)</label>
                    <input type="number" id="prix" name="prix" step="1" min="0"
                           value="<?php echo e(old('prix', $prestation->prix)); ?>">
                    <?php $__errorArgs = ['prix'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="erreur"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="duree">Durée (minutes)</label>
                    <input type="number" id="duree" name="duree" min="1"
                           value="<?php echo e(old('duree', $prestation->duree)); ?>">
                    <?php $__errorArgs = ['duree'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="erreur"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-group">
                <label for="image">Image</label>

                <?php if($prestation->image): ?>
                    <div>
                        <img src="<?php echo e(asset('storage/' . $prestation->image)); ?>"
                             class="image-actuelle"
                             alt="<?php echo e($prestation->nom); ?>">
                    </div>
                <?php endif; ?>

                <input type="file" id="image" name="image" accept="image/*">
                <small style="color:#725d6d;">Laissez vide pour garder l'image actuelle.</small>
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="erreur"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label>
                    <input type="checkbox" name="statut" value="1"
                           <?php echo e(old('statut', $prestation->statut) ? 'checked' : ''); ?>>
                    Prestation active
                </label>
            </div>

            <button type="submit" class="btn-enregistrer">
                <i class="fas fa-save"></i> Enregistrer
            </button>
            <a href="<?php echo e(route('prestations.index')); ?>" class="btn-annuler">Annuler</a>

        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\All_ine_One_by_Eva\resources\views/prestations/edit.blade.php ENDPATH**/ ?>